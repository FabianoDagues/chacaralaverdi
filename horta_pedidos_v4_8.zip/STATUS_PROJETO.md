# Versão 4.0

Atualizações: romaneio em duas vias por pedido, nova ordem de colunas e disponibilidade por intervalo de datas.

# Status do Projeto — Horta Pedidos V3.5

## Implementado
- Empresa e logo vinculadas aos dados.
- CRUD de produtos, clientes e operadores.
- Autocadastro opcional de clientes.
- Disponibilidade diária.
- Pedido do cliente para o dia seguinte, com quantidades inteiras.
- Histórico, edição e exclusão de pedidos dentro das regras.
- Dashboard operacional e lembretes.
- Contas a receber, baixa e recibos consolidados.
- Relatórios gerenciais.
- Rotina protegida para limpeza das movimentações de teste.
- PWA/responsividade para desktop e celular.
- Menu lateral responsivo para operador e cliente.
- Impressão de romaneios restrita exclusivamente aos pedidos com entrega no dia seguinte.

## V3.6
- Dashboard: botões Ver relatório para colher e Imprimir junto aos totais por produto.
- Novo relatório A4 de total para colher por data, com fonte grande e caixa de conferência por produto.
- Impressão do relatório de colheita protegida: somente para a data de entrega do dia seguinte.
- Romaneios: fonte ampliada nas linhas de produtos e quantidades, preservando o formato operacional.

## V3.7
- Logo reduzida nos romaneios e no Total para Colher.
- Produto e quantidade ampliados para leitura operacional (18 px no romaneio; 21/23 px na colheita).
- CSS crítico embutido nos relatórios e cache atualizado para evitar versão antiga do estilo.


## V3.8
- Romaneio com 54% da largura reservada ao produto.
- Produto em 20 px e quantidade em 19 px, usando Arial/Helvetica e peso 700 para leitura grande sem excesso de negrito.
- Preço/total compactados e alinhados à direita.
- Relatório de colheita com tipografia mais leve e ampliada.


## V3.9
- Nome fantasia do cliente ampliado nos romaneios.
- Tipografia dos produtos mais leve e legível.
- Impressões e relatórios internos passam a abrir na mesma guia para evitar acúmulo de abas.


## V4.1 — quantidade segura no pedido
- Botões − e + alteram a quantidade de 1 em 1.
- Ao clicar/tocar no número, o valor atual é selecionado para ser sobrescrito ao digitar.
- O campo aceita somente números inteiros e restaura 0 se for deixado vazio.


## V4.2
- Botões + e - do pedido alteram a quantidade sem focar o campo e sem abrir o teclado no celular.
- Teclado numérico abre somente ao tocar diretamente no campo para digitação manual.


## V4.3
- Romaneio em duas vias na mesma folha A4, sem quebra entre vias.
- Grade do romaneio com valores em fonte 18 normal; cabeçalhos e total em negrito.


## V4.4 — Romaneio adaptativo
- Até 10 itens: 1ª e 2ª via permanecem juntas na mesma folha A4.
- Acima de 10 itens: 1ª via ocupa uma página e 2ª via ocupa a página seguinte, mantendo fonte 18 e evitando cortes.
- Cada pedido começa em sua própria página e nunca é misturado com outro cliente.

- [x] Romaneio em PDF A4 gerado no servidor para impressão consistente em celular e computador.

## V4.6 — Controle de estoque diário
- [x] Estoque opcional por produto/dia e por período.
- [x] Saldo restante descontado automaticamente pelos pedidos enviados.
- [x] Saldo exibido ao cliente apenas para produtos com estoque informado.
- [x] Limite integrado aos botões +/− e à digitação manual.
- [x] Mensagem ao atingir o estoque máximo disponível.
- [x] Erro de estoque preserva os demais itens do pedido.
- [x] Operador visualiza estoque, quantidade já pedida e saldo.
- [x] Rodapé com créditos da PREMIUM SOFTWARE LTDA.


### V4.8
- Prorrogação individual de vencimento no Contas a Receber.
- Recalculo opcional de títulos em aberto ao alterar prazo do cliente.
